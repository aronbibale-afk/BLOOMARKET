import Link from "next/link";
import type { ReactNode } from "react";
import { LogoIcon } from "./Icon";

export function AuthShell({
  title,
  subtitle,
  children,
  bottom,
}: {
  title: string;
  subtitle: string;
  children: ReactNode;
  bottom?: ReactNode;
}) {
  return (
    <div className="bg-mesh min-h-[calc(100vh-4rem)] grid place-items-center px-4 py-12">
      <div className="w-full max-w-md">
        <div className="card p-8">
          <Link href="/" className="mb-6 inline-flex items-center gap-2">
            <LogoIcon size={32} />
            <span className="font-semibold">Bloo<span className="gradient-text">Market</span></span>
          </Link>
          <h1 className="text-2xl font-bold">{title}</h1>
          <p className="mt-1 text-sm text-slate-400">{subtitle}</p>
          <div className="mt-6">{children}</div>
        </div>
        {bottom && <div className="mt-4 text-center text-sm text-slate-400">{bottom}</div>}
      </div>
    </div>
  );
}

export function Field({
  label,
  type = "text",
  placeholder,
  hint,
  name,
}: {
  label: string;
  type?: string;
  placeholder?: string;
  hint?: string;
  name?: string;
}) {
  return (
    <label className="block">
      <span className="mb-1.5 block text-xs font-semibold uppercase text-slate-400">{label}</span>
      <input
        name={name}
        type={type}
        placeholder={placeholder}
        className="w-full rounded-xl border border-white/10 bg-white/5 px-4 py-3 text-sm placeholder:text-slate-500 focus:border-violet-500/50 focus:outline-none focus:ring-2 focus:ring-violet-500/20"
      />
      {hint && <p className="mt-1 text-xs text-slate-500">{hint}</p>}
    </label>
  );
}
