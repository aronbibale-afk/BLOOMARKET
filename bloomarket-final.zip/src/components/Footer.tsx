import Link from "next/link";
import { GAMES } from "@/lib/games";

export function Footer() {
  return (
    <footer className="border-t border-[#1C2433] bg-[#080B0F] mt-24">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 py-16">
        <div className="grid grid-cols-2 gap-10 md:grid-cols-4">
          {/* Brand */}
          <div className="col-span-2 md:col-span-1">
            <div className="flex items-center gap-2.5 mb-4">
              <svg width="26" height="26" viewBox="0 0 28 28" fill="none"><rect width="28" height="28" rx="8" fill="#3BF4A0"/><path d="M8 8h6a4 4 0 0 1 4 4v0a4 4 0 0 1-4 4H8V8z" fill="#080B0F"/><path d="M8 16h6.5a3.5 3.5 0 0 1 3.5 3.5v0a.5.5 0 0 1-.5.5H8v-4z" fill="#080B0F"/></svg>
              <span className="font-display text-[16px] font-700 text-white">Bloo<span className="text-[#3BF4A0]">market</span></span>
            </div>
            <p className="text-[13px] text-[#6B7A90] leading-relaxed max-w-[200px]">
              La marketplace Roblox la plus rapide. Paiements sécurisés, livraison instantanée.
            </p>
            <div className="flex items-center gap-2 mt-5">
              <span className="badge-mint">Sécurisé</span>
              <span className="badge-mint">Vérifié</span>
            </div>
          </div>

          {/* Jeux */}
          <div>
            <p className="section-label mb-4">Jeux</p>
            <ul className="space-y-2.5">
              {GAMES.map((g) => (
                <li key={g.slug}>
                  <Link href={`/catalog?game=${g.slug}`} className="text-[13px] text-[#6B7A90] hover:text-white transition-colors flex items-center gap-2">
                    <span>{g.emoji}</span>{g.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Marketplace */}
          <div>
            <p className="section-label mb-4">Marketplace</p>
            <ul className="space-y-2.5">
              {["Catalogue", "Promos du moment", "Vendeurs vérifiés", "Devenir vendeur", "Programme affilié"].map((item) => (
                <li key={item}>
                  <Link href="/catalog" className="text-[13px] text-[#6B7A90] hover:text-white transition-colors">
                    {item}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Support */}
          <div>
            <p className="section-label mb-4">Support</p>
            <ul className="space-y-2.5">
              {["Comment ça marche", "Garantie remboursement", "Politique de confidentialité", "CGU", "Contact"].map((item) => (
                <li key={item}>
                  <Link href="#" className="text-[13px] text-[#6B7A90] hover:text-white transition-colors">
                    {item}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        </div>

        <div className="mt-12 pt-8 border-t border-[#1C2433] flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-[12px] text-[#4A5568]">
            © 2025 Bloomarket. Tous droits réservés. Non affilié à Roblox Corporation.
          </p>
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-1.5 text-[12px] text-[#6B7A90]">
              <span className="live-dot" />
              <span>Tous systèmes opérationnels</span>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
