"use client";

import Link from "next/link";
import { useState } from "react";
import { GAMES } from "@/lib/games";

function Logo() {
  return (
    <svg width="28" height="28" viewBox="0 0 28 28" fill="none" xmlns="http://www.w3.org/2000/svg">
      <rect width="28" height="28" rx="8" fill="#3BF4A0"/>
      <path d="M8 8h6a4 4 0 0 1 4 4v0a4 4 0 0 1-4 4H8V8z" fill="#080B0F"/>
      <path d="M8 16h6.5a3.5 3.5 0 0 1 3.5 3.5v0a.5.5 0 0 1-.5.5H8v-4z" fill="#080B0F"/>
    </svg>
  );
}

export function Header() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [gamesOpen, setGamesOpen] = useState(false);

  return (
    <header className="sticky top-0 z-50 border-b border-[#1C2433] bg-[#080B0F]/90 backdrop-blur-xl">
      <div className="mx-auto flex h-[60px] max-w-7xl items-center gap-6 px-4 sm:px-6">
        {/* Logo */}
        <Link href="/" className="flex items-center gap-2.5 flex-shrink-0">
          <Logo />
          <span className="font-display text-[17px] font-700 tracking-tight text-white">
            Bloo<span className="text-[#3BF4A0]">market</span>
          </span>
        </Link>

        {/* Nav desktop */}
        <nav className="hidden items-center gap-1 lg:flex">
          <div
            className="relative"
            onMouseEnter={() => setGamesOpen(true)}
            onMouseLeave={() => setGamesOpen(false)}
          >
            <button className="flex items-center gap-1.5 rounded-lg px-3 py-2 text-sm text-[#A0AABF] hover:text-white transition-colors">
              Jeux
              <svg width="12" height="12" viewBox="0 0 12 12" fill="currentColor">
                <path d="M2 4l4 4 4-4" stroke="currentColor" strokeWidth="1.5" fill="none" strokeLinecap="round"/>
              </svg>
            </button>
            {gamesOpen && (
              <div className="absolute left-0 top-full w-72 pt-2">
                <div className="glass rounded-xl p-2 shadow-2xl">
                  {GAMES.map((g) => (
                    <Link
                      key={g.slug}
                      href={`/catalog?game=${g.slug}`}
                      className="flex items-center gap-3 rounded-lg px-3 py-2.5 hover:bg-white/5 transition-colors"
                    >
                      <span className={`flex h-9 w-9 items-center justify-center rounded-lg bg-gradient-to-br ${g.gradient} text-lg flex-shrink-0`}>
                        {g.emoji}
                      </span>
                      <div>
                        <div className="text-sm font-semibold text-white">{g.name}</div>
                        <div className="text-xs text-[#6B7A90]">{g.players} joueurs actifs</div>
                      </div>
                    </Link>
                  ))}
                </div>
              </div>
            )}
          </div>
          <Link href="/catalog" className="rounded-lg px-3 py-2 text-sm text-[#A0AABF] hover:text-white transition-colors">
            Catalogue
          </Link>
          <Link href="/catalog?type=Service" className="rounded-lg px-3 py-2 text-sm text-[#A0AABF] hover:text-white transition-colors">
            Services
          </Link>
          <Link href="/catalog?sort=sale" className="flex items-center gap-1.5 rounded-lg px-3 py-2 text-sm text-[#FF6B35] hover:text-[#FF8C5A] transition-colors">
            <span className="relative flex h-1.5 w-1.5">
              <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-[#FF6B35] opacity-75"></span>
              <span className="relative inline-flex h-1.5 w-1.5 rounded-full bg-[#FF6B35]"></span>
            </span>
            Promos
          </Link>
        </nav>

        {/* Right */}
        <div className="ml-auto flex items-center gap-2">
          <Link
            href="/catalog"
            className="hidden sm:flex h-9 w-9 items-center justify-center rounded-lg border border-[#1C2433] text-[#6B7A90] hover:text-white hover:border-[#2A3A50] transition-all"
          >
            <svg width="16" height="16" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round">
              <circle cx="7" cy="7" r="5"/>
              <path d="M13 13l-2-2"/>
            </svg>
          </Link>
          <Link
            href="/login"
            className="btn-ghost hidden sm:block rounded-lg px-4 py-2 text-sm"
          >
            Connexion
          </Link>
          <Link
            href="/register"
            className="btn-mint rounded-lg px-4 py-2 text-sm"
          >
            Vendre
          </Link>

          {/* Mobile menu button */}
          <button
            className="lg:hidden ml-1 flex h-9 w-9 items-center justify-center rounded-lg border border-[#1C2433]"
            onClick={() => setMenuOpen(!menuOpen)}
          >
            {menuOpen ? (
              <svg width="16" height="16" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"><path d="M2 2l12 12M14 2L2 14"/></svg>
            ) : (
              <svg width="16" height="16" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"><path d="M2 4h12M2 8h12M2 12h12"/></svg>
            )}
          </button>
        </div>
      </div>

      {/* Mobile menu */}
      {menuOpen && (
        <div className="lg:hidden border-t border-[#1C2433] bg-[#080B0F] px-4 py-4">
          <div className="space-y-1">
            {GAMES.map((g) => (
              <Link
                key={g.slug}
                href={`/catalog?game=${g.slug}`}
                onClick={() => setMenuOpen(false)}
                className="flex items-center gap-3 rounded-lg px-3 py-3 hover:bg-white/5"
              >
                <span className={`flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br ${g.gradient}`}>{g.emoji}</span>
                <span className="text-sm text-white">{g.name}</span>
              </Link>
            ))}
            <div className="border-t border-[#1C2433] mt-3 pt-3 space-y-1">
              <Link href="/catalog" onClick={() => setMenuOpen(false)} className="block rounded-lg px-3 py-2 text-sm text-[#A0AABF]">Catalogue</Link>
              <Link href="/login" onClick={() => setMenuOpen(false)} className="block rounded-lg px-3 py-2 text-sm text-[#A0AABF]">Connexion</Link>
            </div>
          </div>
        </div>
      )}
    </header>
  );
}
