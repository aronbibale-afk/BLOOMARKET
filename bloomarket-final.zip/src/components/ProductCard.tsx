import Link from "next/link";
import type { Product } from "@/lib/mock-data";
import { getGameBySlug } from "@/lib/games";

export function ProductCard({ product }: { product: Product }) {
  const game = getGameBySlug(product.gameSlug);
  const discount = product.oldPrice
    ? Math.round((1 - product.price / product.oldPrice) * 100)
    : null;

  return (
    <Link href={`/product/${product.id}`} className="scan-card group block">
      {/* Thumbnail */}
      <div className={`relative aspect-[4/3] overflow-hidden bg-gradient-to-br ${product.gradient} rounded-t-[13px]`}>
        <div className="absolute inset-0 grid-lines opacity-30" />
        {/* Emoji */}
        <div className="absolute inset-0 flex items-center justify-center text-[72px] transition-transform duration-500 group-hover:scale-110 drop-shadow-2xl select-none">
          {product.emoji}
        </div>
        {/* Badges top */}
        <div className="absolute left-3 top-3 flex gap-1.5">
          {discount && (
            <span className="badge-sale">-{discount}%</span>
          )}
          {product.stock <= 5 && (
            <span className="badge-orange">Stock limité</span>
          )}
        </div>
        <div className="absolute right-3 top-3">
          <span className={`text-[10px] font-semibold px-2 py-1 rounded-md type-${product.type}`}>
            {product.type}
          </span>
        </div>
        {/* Game tag bottom */}
        {game && (
          <div className="absolute bottom-2.5 left-3 flex items-center gap-1.5 rounded-lg bg-black/50 px-2.5 py-1 text-[11px] backdrop-blur-md">
            <span>{game.emoji}</span>
            <span className="text-white/80 font-medium">{game.name}</span>
          </div>
        )}
        {/* Delivery */}
        <div className="absolute bottom-2.5 right-3 flex items-center gap-1 text-[11px] text-[#3BF4A0] font-medium">
          <span className="live-dot scale-75" />
          {product.delivery}
        </div>
      </div>

      {/* Body */}
      <div className="p-4">
        <div className="flex items-start justify-between gap-2 mb-1">
          <h3 className="font-display font-600 text-[14px] text-white leading-tight line-clamp-1">
            {product.title}
          </h3>
          <div className="flex items-center gap-0.5 text-amber-400 flex-shrink-0">
            <svg width="11" height="11" viewBox="0 0 12 12" fill="currentColor"><path d="M6 1l1.55 3.14L11 4.63l-2.5 2.44.59 3.43L6 9 2.91 10.5l.59-3.43L1 4.63l3.45-.49z"/></svg>
            <span className="text-[12px] font-medium text-amber-400">{product.rating}</span>
            <span className="text-[11px] text-[#4A5568] ml-0.5">({product.reviewCount})</span>
          </div>
        </div>

        <p className="text-[12px] text-[#6B7A90] line-clamp-1 mb-3">{product.description}</p>

        {/* Seller */}
        <div className="flex items-center gap-2 mb-3">
          <span className="text-[15px]">{product.seller.avatar}</span>
          <span className="text-[12px] text-[#6B7A90] truncate">{product.seller.name}</span>
          {product.seller.verified && (
            <span className="verified-badge flex-shrink-0" title="Vendeur vérifié">
              <svg width="9" height="9" viewBox="0 0 10 10" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
                <path d="M2 5l2 2 4-4"/>
              </svg>
            </span>
          )}
        </div>

        {/* Price row */}
        <div className="flex items-end justify-between pt-3 border-t border-[#1C2433]">
          <div>
            {product.oldPrice && (
              <div className="text-[11px] text-[#4A5568] line-through leading-none mb-0.5">
                {product.oldPrice.toFixed(2)}€
              </div>
            )}
            <div className="font-display text-[20px] font-800 text-white leading-none">
              {product.price.toFixed(2)}€
            </div>
          </div>
          <div className="h-8 w-8 rounded-lg bg-[#3BF4A0]/10 flex items-center justify-center text-[#3BF4A0] transition-all group-hover:bg-[#3BF4A0] group-hover:text-[#080B0F]">
            <svg width="14" height="14" viewBox="0 0 14 14" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M7 1l6 6-6 6M1 7h12"/>
            </svg>
          </div>
        </div>
      </div>
    </Link>
  );
}
