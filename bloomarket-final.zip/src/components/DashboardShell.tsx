"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import type { ReactNode } from "react";
import { ChartIcon, DollarIcon, GiftIcon, HeartIcon, PackageIcon, SettingsIcon, ShieldIcon, TicketIcon, UserIcon, UsersIcon } from "./Icon";

type NavItem = { href: string; label: string; icon: ReactNode };

const NAVS: Record<string, { title: string; items: NavItem[] }> = {
  user: {
    title: "Mon espace",
    items: [
      { href: "/dashboard", label: "Profil", icon: <UserIcon size={18} /> },
      { href: "/dashboard?tab=orders", label: "Commandes", icon: <PackageIcon size={18} /> },
      { href: "/dashboard?tab=favorites", label: "Favoris", icon: <HeartIcon size={18} /> },
      { href: "/dashboard?tab=settings", label: "Paramètres", icon: <SettingsIcon size={18} /> },
    ],
  },
  seller: {
    title: "Espace vendeur",
    items: [
      { href: "/dashboard/seller", label: "Vue d'ensemble", icon: <ChartIcon size={18} /> },
      { href: "/dashboard/seller?tab=products", label: "Mes produits", icon: <PackageIcon size={18} /> },
      { href: "/dashboard/seller?tab=add", label: "Ajouter un produit", icon: <GiftIcon size={18} /> },
      { href: "/dashboard/seller?tab=sales", label: "Ventes", icon: <DollarIcon size={18} /> },
      { href: "/dashboard/seller?tab=verification", label: "Vérification", icon: <ShieldIcon size={18} /> },
    ],
  },
  affiliate: {
    title: "Affiliation",
    items: [
      { href: "/dashboard/affiliate", label: "Tableau de bord", icon: <ChartIcon size={18} /> },
      { href: "/dashboard/affiliate?tab=link", label: "Mon code", icon: <GiftIcon size={18} /> },
      { href: "/dashboard/affiliate?tab=payouts", label: "Paiements", icon: <DollarIcon size={18} /> },
    ],
  },
  admin: {
    title: "Administration",
    items: [
      { href: "/dashboard/admin", label: "Statistiques", icon: <ChartIcon size={18} /> },
      { href: "/dashboard/admin?tab=users", label: "Utilisateurs", icon: <UsersIcon size={18} /> },
      { href: "/dashboard/admin?tab=sellers", label: "Vendeurs", icon: <ShieldIcon size={18} /> },
      { href: "/dashboard/admin?tab=orders", label: "Commandes", icon: <PackageIcon size={18} /> },
      { href: "/dashboard/admin?tab=disputes", label: "Litiges", icon: <TicketIcon size={18} /> },
      { href: "/dashboard/admin?tab=commissions", label: "Commissions", icon: <DollarIcon size={18} /> },
    ],
  },
};

const SECTIONS: { key: keyof typeof NAVS; label: string; href: string }[] = [
  { key: "user", label: "Utilisateur", href: "/dashboard" },
  { key: "seller", label: "Vendeur", href: "/dashboard/seller" },
  { key: "affiliate", label: "Affiliation", href: "/dashboard/affiliate" },
  { key: "admin", label: "Admin", href: "/dashboard/admin" },
];

export function DashboardShell({
  section,
  title,
  subtitle,
  children,
}: {
  section: keyof typeof NAVS;
  title: string;
  subtitle?: string;
  children: ReactNode;
}) {
  const pathname = usePathname();
  const nav = NAVS[section];

  return (
    <div className="bg-mesh min-h-[calc(100vh-4rem)]">
      <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6">
        {/* Section switcher */}
        <div className="mb-6 flex flex-wrap items-center gap-2">
          {SECTIONS.map((s) => (
            <Link
              key={s.key}
              href={s.href}
              className={`rounded-full px-4 py-1.5 text-xs font-medium ${
                section === s.key
                  ? "bg-violet-500/20 text-violet-200 border border-violet-500/30"
                  : "border border-white/10 bg-white/5 text-slate-400 hover:text-white"
              }`}
            >
              {s.label}
            </Link>
          ))}
        </div>

        <div className="grid gap-6 lg:grid-cols-[240px_1fr]">
          <aside className="card p-4 h-fit lg:sticky lg:top-20">
            <div className="px-3 pb-3 text-xs font-semibold uppercase text-slate-500">{nav.title}</div>
            <nav className="space-y-1">
              {nav.items.map((item) => {
                const active = pathname + ((typeof window !== "undefined") ? window.location.search : "") === item.href || pathname === item.href.split("?")[0];
                return (
                  <Link
                    key={item.href}
                    href={item.href}
                    className={`flex items-center gap-3 rounded-lg px-3 py-2 text-sm ${
                      active ? "bg-white/5 text-white" : "text-slate-400 hover:bg-white/5 hover:text-white"
                    }`}
                  >
                    {item.icon}
                    {item.label}
                  </Link>
                );
              })}
            </nav>
          </aside>

          <div>
            <header className="mb-6">
              <h1 className="text-3xl font-bold tracking-tight">{title}</h1>
              {subtitle && <p className="mt-1 text-sm text-slate-400">{subtitle}</p>}
            </header>
            {children}
          </div>
        </div>
      </div>
    </div>
  );
}

export function StatCard({ label, value, sub, icon }: { label: string; value: string; sub?: string; icon?: ReactNode }) {
  return (
    <div className="card p-5">
      <div className="flex items-start justify-between">
        <div>
          <div className="text-xs text-slate-400">{label}</div>
          <div className="mt-1 text-2xl font-bold">{value}</div>
          {sub && <div className="mt-1 text-xs text-emerald-400">{sub}</div>}
        </div>
        {icon && <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-violet-500/15 text-violet-300">{icon}</div>}
      </div>
    </div>
  );
}
