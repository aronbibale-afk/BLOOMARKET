"use client";

type Point = { label: string; value: number };

export function BarChart({ data, color = "#7c5cff", height = 180 }: { data: Point[]; color?: string; height?: number }) {
  const max = Math.max(...data.map((d) => d.value), 1);
  return (
    <div className="w-full">
      <div className="flex items-end gap-2" style={{ height }}>
        {data.map((d) => (
          <div key={d.label} className="flex flex-1 flex-col items-center gap-2">
            <div className="flex w-full flex-1 items-end">
              <div
                className="w-full rounded-t-md transition-all"
                style={{
                  height: `${(d.value / max) * 100}%`,
                  background: `linear-gradient(180deg, ${color}cc, ${color}66)`,
                  minHeight: 4,
                }}
              />
            </div>
            <div className="text-[10px] text-slate-500">{d.label}</div>
          </div>
        ))}
      </div>
    </div>
  );
}

export function LineChart({ data, color = "#2dd4bf", height = 180 }: { data: Point[]; color?: string; height?: number }) {
  const w = 600;
  const h = height;
  const pad = 16;
  const max = Math.max(...data.map((d) => d.value), 1);
  const min = Math.min(...data.map((d) => d.value), 0);
  const range = max - min || 1;
  const step = (w - pad * 2) / Math.max(1, data.length - 1);

  const points = data.map((d, i) => {
    const x = pad + i * step;
    const y = pad + (1 - (d.value - min) / range) * (h - pad * 2);
    return [x, y] as const;
  });
  const path = points.map(([x, y], i) => `${i === 0 ? "M" : "L"} ${x} ${y}`).join(" ");
  const area = `${path} L ${points[points.length - 1][0]} ${h - pad} L ${points[0][0]} ${h - pad} Z`;

  return (
    <div className="w-full">
      <svg viewBox={`0 0 ${w} ${h}`} className="h-full w-full" preserveAspectRatio="none">
        <defs>
          <linearGradient id="lc-area" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor={color} stopOpacity="0.4" />
            <stop offset="100%" stopColor={color} stopOpacity="0" />
          </linearGradient>
        </defs>
        <path d={area} fill="url(#lc-area)" />
        <path d={path} stroke={color} strokeWidth="2.5" fill="none" />
        {points.map(([x, y], i) => (
          <circle key={i} cx={x} cy={y} r="3" fill={color} />
        ))}
      </svg>
      <div className="mt-1 flex justify-between text-[10px] text-slate-500">
        {data.map((d) => <span key={d.label}>{d.label}</span>)}
      </div>
    </div>
  );
}
