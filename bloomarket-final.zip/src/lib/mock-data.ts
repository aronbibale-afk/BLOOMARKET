import { GAMES } from "./games";

export type Product = {
  id: string;
  title: string;
  description: string;
  longDescription: string;
  price: number;
  oldPrice?: number;
  gameSlug: string;
  type: "Devise" | "Objet" | "Brainrot" | "Compte" | "Service";
  seller: {
    id: string;
    name: string;
    avatar: string;
    verified: boolean;
    rating: number;
    sales: number;
    memberSince: string;
  };
  rating: number;
  reviewCount: number;
  stock: number;
  delivery: string;
  emoji: string;
  gradient: string;
  tags: string[];
  popularity: number; // for sorting
};

const sellers = [
  { id: "s1", name: "BloxLegend", avatar: "🦅", verified: true, rating: 4.9, sales: 4821, memberSince: "Mars 2022" },
  { id: "s2", name: "PixelKing", avatar: "👑", verified: true, rating: 4.95, sales: 8124, memberSince: "Janvier 2021" },
  { id: "s3", name: "RobloxPro", avatar: "🎮", verified: true, rating: 4.8, sales: 2310, memberSince: "Septembre 2023" },
  { id: "s4", name: "GardenGod", avatar: "🌿", verified: false, rating: 4.6, sales: 412, memberSince: "Mai 2024" },
  { id: "s5", name: "MM2Master", avatar: "🗡️", verified: true, rating: 5.0, sales: 9302, memberSince: "Août 2020" },
  { id: "s6", name: "BrainrotKing", avatar: "🧠", verified: true, rating: 4.85, sales: 3214, memberSince: "Février 2024" },
];

const productSeeds: Array<Omit<Product, "id" | "seller" | "rating" | "reviewCount" | "popularity"> & { sellerIdx: number; rating: number; reviewCount: number; popularity: number }> = [
  // Steal A Brainrot
  { title: "Tung Tung Sahur (Brainrot)", description: "Brainrot rare livré sous 5 minutes", longDescription: "Obtenez le Brainrot Tung Tung Sahur, l'un des plus convoités du jeu. Livraison en main propre dans une partie privée, 100% sécurisé.", price: 12.99, oldPrice: 19.99, gameSlug: "steal-a-brainrot", type: "Brainrot", sellerIdx: 5, rating: 4.9, reviewCount: 312, stock: 47, delivery: "5 min", emoji: "🧠", gradient: "from-fuchsia-500 to-purple-700", tags: ["rare", "trending", "livraison rapide"], popularity: 980 },
  { title: "Bombardiro Crocodilo", description: "Brainrot ultra rare édition limitée", longDescription: "Le mythique Bombardiro Crocodilo, livré directement dans votre inventaire. Stock limité.", price: 34.99, gameSlug: "steal-a-brainrot", type: "Brainrot", sellerIdx: 0, rating: 4.85, reviewCount: 187, stock: 12, delivery: "10 min", emoji: "🐊", gradient: "from-emerald-500 to-fuchsia-600", tags: ["ultra rare", "limité"], popularity: 940 },
  { title: "1M Cash Steal A Brainrot", description: "1 million de cash in-game", longDescription: "Recevez 1 000 000 de cash directement dans votre partie. Méthode 100% safe utilisée par +5000 clients.", price: 4.99, gameSlug: "steal-a-brainrot", type: "Devise", sellerIdx: 1, rating: 5.0, reviewCount: 1240, stock: 999, delivery: "Instantané", emoji: "💵", gradient: "from-emerald-400 to-green-600", tags: ["best seller", "instant"], popularity: 1000 },
  { title: "Compte Lvl 50 + 10 Brainrots", description: "Compte starter complet", longDescription: "Compte vérifié niveau 50 avec 10 Brainrots rares déjà débloqués. Transfert d'email garanti.", price: 49.0, oldPrice: 79.0, gameSlug: "steal-a-brainrot", type: "Compte", sellerIdx: 0, rating: 4.7, reviewCount: 56, stock: 3, delivery: "30 min", emoji: "🎟️", gradient: "from-indigo-500 to-purple-700", tags: ["compte", "premium"], popularity: 720 },

  // Grow A Garden
  { title: "Pack Seeds Légendaires x20", description: "20 seeds légendaires assorties", longDescription: "Pack de 20 seeds légendaires aléatoires pour booster votre jardin. Compatible avec toutes les saisons.", price: 8.49, gameSlug: "grow-a-garden", type: "Objet", sellerIdx: 3, rating: 4.6, reviewCount: 92, stock: 120, delivery: "Instantané", emoji: "🌻", gradient: "from-emerald-400 to-teal-600", tags: ["pack", "légendaire"], popularity: 880 },
  { title: "500K Sheckles", description: "500 000 Sheckles in-game", longDescription: "Livraison rapide de 500 000 Sheckles dans votre jardin. Méthode trade safe.", price: 6.99, gameSlug: "grow-a-garden", type: "Devise", sellerIdx: 3, rating: 4.8, reviewCount: 340, stock: 999, delivery: "10 min", emoji: "💰", gradient: "from-yellow-400 to-amber-600", tags: ["devise", "best seller"], popularity: 960 },
  { title: "Plante Mythic Dragon Fruit", description: "Plante mythic ultra rare", longDescription: "La très convoitée plante Mythic Dragon Fruit, drop rate <0.1%. Livraison via trade sécurisé.", price: 24.99, gameSlug: "grow-a-garden", type: "Objet", sellerIdx: 3, rating: 4.9, reviewCount: 41, stock: 5, delivery: "20 min", emoji: "🐉", gradient: "from-rose-500 to-orange-500", tags: ["mythic", "rare"], popularity: 820 },

  // Blox Fruits
  { title: "Dragon Fruit (Permanent)", description: "Fruit Dragon permanent rare", longDescription: "Obtenez le Dragon Fruit en version permanente. Le fruit le plus puissant du jeu, livré en main propre.", price: 89.99, oldPrice: 129.99, gameSlug: "blox-fruits", type: "Objet", sellerIdx: 2, rating: 4.95, reviewCount: 218, stock: 4, delivery: "1h", emoji: "🐉", gradient: "from-rose-500 to-red-700", tags: ["permanent", "top tier"], popularity: 990 },
  { title: "Leo Fruit (Permanent)", description: "Fruit Leo permanent", longDescription: "Leo Fruit permanent disponible. Stock limité, livraison rapide.", price: 24.99, gameSlug: "blox-fruits", type: "Objet", sellerIdx: 2, rating: 4.85, reviewCount: 134, stock: 8, delivery: "30 min", emoji: "🦁", gradient: "from-yellow-500 to-orange-600", tags: ["permanent"], popularity: 870 },
  { title: "Leveling Max (1 → 2450)", description: "Service de leveling complet", longDescription: "Notre équipe pro vous level up de 1 à 2450 en moins de 48h. Compte en sécurité, VPN dédié.", price: 39.99, gameSlug: "blox-fruits", type: "Service", sellerIdx: 2, rating: 4.9, reviewCount: 612, stock: 50, delivery: "24-48h", emoji: "⚡", gradient: "from-yellow-400 to-rose-500", tags: ["service", "rapide"], popularity: 930 },
  { title: "10M Beli", description: "10 millions de Beli", longDescription: "10 000 000 Beli livrés en main propre. Méthode safe trade.", price: 5.49, gameSlug: "blox-fruits", type: "Devise", sellerIdx: 1, rating: 4.95, reviewCount: 890, stock: 999, delivery: "15 min", emoji: "💴", gradient: "from-amber-400 to-orange-600", tags: ["devise"], popularity: 950 },

  // MM2
  { title: "Chroma Lightbringer", description: "Couteau Chroma godly", longDescription: "Le légendaire Chroma Lightbringer, l'un des couteaux les plus rares de MM2. Trade in-game sécurisé.", price: 59.99, gameSlug: "mm2", type: "Objet", sellerIdx: 4, rating: 5.0, reviewCount: 156, stock: 2, delivery: "1h", emoji: "🗡️", gradient: "from-cyan-400 to-fuchsia-500", tags: ["chroma", "godly"], popularity: 910 },
  { title: "Pack 5 Godlies", description: "5 couteaux godly aléatoires", longDescription: "Recevez 5 couteaux godly aléatoires d'une valeur garantie supérieure à votre achat.", price: 19.99, gameSlug: "mm2", type: "Objet", sellerIdx: 4, rating: 4.8, reviewCount: 304, stock: 35, delivery: "30 min", emoji: "🎁", gradient: "from-purple-500 to-pink-600", tags: ["pack"], popularity: 860 },
  { title: "Corrupt", description: "Couteau Corrupt ancien", longDescription: "Couteau Corrupt, un classique recherché par les collectionneurs.", price: 14.99, gameSlug: "mm2", type: "Objet", sellerIdx: 4, rating: 4.7, reviewCount: 78, stock: 18, delivery: "20 min", emoji: "🔮", gradient: "from-indigo-500 to-purple-700", tags: ["ancien"], popularity: 700 },

  // Pet Simulator
  { title: "Huge Hacked Cat", description: "Huge pet ultra rare", longDescription: "Le très convoité Huge Hacked Cat, en stock limité. Trade in-game safe.", price: 79.99, oldPrice: 119.99, gameSlug: "pet-simulator", type: "Objet", sellerIdx: 0, rating: 4.9, reviewCount: 244, stock: 6, delivery: "30 min", emoji: "😺", gradient: "from-cyan-400 to-blue-600", tags: ["huge", "exclusif"], popularity: 970 },
  { title: "100B Gems", description: "100 milliards de gems", longDescription: "100 000 000 000 de gems livrés en partie privée. Méthode safe.", price: 9.99, gameSlug: "pet-simulator", type: "Devise", sellerIdx: 1, rating: 5.0, reviewCount: 1520, stock: 999, delivery: "Instantané", emoji: "💎", gradient: "from-cyan-300 to-sky-600", tags: ["devise", "best seller"], popularity: 1000 },
  { title: "Pack 3 Huge Pets", description: "3 Huge pets aléatoires", longDescription: "3 Huge pets aléatoires garantis, valeur supérieure à votre achat.", price: 49.99, gameSlug: "pet-simulator", type: "Objet", sellerIdx: 0, rating: 4.85, reviewCount: 112, stock: 14, delivery: "1h", emoji: "🎁", gradient: "from-pink-500 to-rose-600", tags: ["pack"], popularity: 890 },
];

export const PRODUCTS: Product[] = productSeeds.map((p, i) => ({
  ...p,
  id: `p-${i + 1}`,
  seller: sellers[p.sellerIdx],
}));

export function getProductById(id: string): Product | undefined {
  return PRODUCTS.find((p) => p.id === id);
}

export function getProductsByGame(slug: string): Product[] {
  return PRODUCTS.filter((p) => p.gameSlug === slug);
}

export function getSimilarProducts(product: Product, limit = 4): Product[] {
  return PRODUCTS.filter((p) => p.gameSlug === product.gameSlug && p.id !== product.id).slice(0, limit);
}

export function getPopularProducts(limit = 8): Product[] {
  return [...PRODUCTS].sort((a, b) => b.popularity - a.popularity).slice(0, limit);
}

export type Review = {
  id: string;
  user: string;
  avatar: string;
  rating: number;
  comment: string;
  date: string;
  game: string;
};

export const REVIEWS: Review[] = [
  { id: "r1", user: "Lucas M.", avatar: "🦊", rating: 5, comment: "Livraison ultra rapide, j'ai reçu mes Brainrots en 3 minutes. Vendeur top !", date: "Il y a 2 jours", game: "Steal A Brainrot" },
  { id: "r2", user: "Emma L.", avatar: "🦄", rating: 5, comment: "Site très pro, paiement sécurisé via Stripe, je recommande à 1000%.", date: "Il y a 5 jours", game: "Blox Fruits" },
  { id: "r3", user: "Hugo R.", avatar: "🐺", rating: 4, comment: "Bon prix, livraison rapide. Le vendeur a été très réactif sur le chat.", date: "Il y a 1 semaine", game: "MM2" },
  { id: "r4", user: "Léa T.", avatar: "🐱", rating: 5, comment: "J'ai eu un Huge pet en moins de 20 minutes, parfait.", date: "Il y a 3 jours", game: "Pet Simulator" },
  { id: "r5", user: "Mathis P.", avatar: "🦁", rating: 5, comment: "Premier achat, j'avais des doutes, mais tout s'est passé impeccable.", date: "Il y a 1 jour", game: "Grow A Garden" },
  { id: "r6", user: "Chloé V.", avatar: "🐰", rating: 5, comment: "Service client au top, problème résolu en 10 minutes via le ticket.", date: "Il y a 4 jours", game: "Blox Fruits" },
];

export const SITE_STATS = {
  users: "248k+",
  sellers: "3.2k+",
  ordersDay: "18 400+",
  rating: "4.9 / 5",
  games: GAMES.length,
  payout: "98%",
};

// Mock orders, favorites, etc. for dashboards
export const MOCK_ORDERS = [
  { id: "ORD-10293", product: "1M Cash Steal A Brainrot", amount: 4.99, status: "Livrée", date: "12 Mar 2026", seller: "PixelKing" },
  { id: "ORD-10287", product: "Dragon Fruit (Permanent)", amount: 89.99, status: "En cours", date: "10 Mar 2026", seller: "RobloxPro" },
  { id: "ORD-10245", product: "Pack 5 Godlies", amount: 19.99, status: "Livrée", date: "5 Mar 2026", seller: "MM2Master" },
  { id: "ORD-10211", product: "Huge Hacked Cat", amount: 79.99, status: "Livrée", date: "1 Mar 2026", seller: "BloxLegend" },
  { id: "ORD-10199", product: "500K Sheckles", amount: 6.99, status: "Litige", date: "27 Fév 2026", seller: "GardenGod" },
];

export const MOCK_SELLER_SALES = [
  { id: "SAL-2034", product: "1M Cash Steal A Brainrot", amount: 4.99, buyer: "Lucas M.", date: "12 Mar 2026", status: "Livrée" },
  { id: "SAL-2033", product: "Pack Seeds Légendaires x20", amount: 8.49, buyer: "Emma L.", date: "11 Mar 2026", status: "Livrée" },
  { id: "SAL-2030", product: "Huge Hacked Cat", amount: 79.99, buyer: "Hugo R.", date: "9 Mar 2026", status: "En cours" },
  { id: "SAL-2025", product: "Dragon Fruit", amount: 89.99, buyer: "Léa T.", date: "7 Mar 2026", status: "Livrée" },
  { id: "SAL-2018", product: "100B Gems", amount: 9.99, buyer: "Mathis P.", date: "5 Mar 2026", status: "Livrée" },
];

export const MOCK_REVENUE_DATA = [
  { month: "Oct", revenue: 1240 },
  { month: "Nov", revenue: 1820 },
  { month: "Déc", revenue: 2410 },
  { month: "Jan", revenue: 3050 },
  { month: "Fév", revenue: 4120 },
  { month: "Mar", revenue: 5840 },
];

export const MOCK_AFFILIATE_DATA = [
  { day: "Lun", clicks: 124, sales: 8 },
  { day: "Mar", clicks: 198, sales: 14 },
  { day: "Mer", clicks: 167, sales: 11 },
  { day: "Jeu", clicks: 245, sales: 19 },
  { day: "Ven", clicks: 312, sales: 27 },
  { day: "Sam", clicks: 401, sales: 35 },
  { day: "Dim", clicks: 378, sales: 31 },
];
