export type Game = {
  slug: string;
  name: string;
  tagline: string;
  emoji: string;
  gradient: string; // tailwind gradient classes
  players: string;
  categories: string[];
};

// Architecture scalable : pour ajouter un nouveau jeu Roblox,
// il suffit d'ajouter une entrée ici.
export const GAMES: Game[] = [
  {
    slug: "steal-a-brainrot",
    name: "Steal A Brainrot",
    tagline: "Vole les meilleurs Brainrots",
    emoji: "🧠",
    gradient: "from-fuchsia-500 via-purple-600 to-indigo-600",
    players: "1.2M",
    categories: ["Brainrot", "Devises", "Comptes", "Services"],
  },
  {
    slug: "grow-a-garden",
    name: "Grow A Garden",
    tagline: "Plantes rares et seeds premium",
    emoji: "🌱",
    gradient: "from-emerald-400 via-teal-500 to-green-600",
    players: "890K",
    categories: ["Plantes", "Seeds", "Devises", "Comptes"],
  },
  {
    slug: "blox-fruits",
    name: "Blox Fruits",
    tagline: "Fruits, items et leveling",
    emoji: "🍎",
    gradient: "from-rose-500 via-red-500 to-orange-500",
    players: "2.4M",
    categories: ["Fruits", "Items", "Leveling", "Comptes"],
  },
  {
    slug: "mm2",
    name: "Murder Mystery 2",
    tagline: "Couteaux, knives & godlies",
    emoji: "🔪",
    gradient: "from-slate-500 via-zinc-600 to-gray-700",
    players: "650K",
    categories: ["Knives", "Guns", "Pets", "Bundles"],
  },
  {
    slug: "pet-simulator",
    name: "Pet Simulator",
    tagline: "Pets exclusifs et huge pets",
    emoji: "🐾",
    gradient: "from-sky-400 via-blue-500 to-indigo-600",
    players: "1.8M",
    categories: ["Pets", "Huges", "Gems", "Comptes"],
  },
];

export function getGameBySlug(slug: string): Game | undefined {
  return GAMES.find((g) => g.slug === slug);
}
