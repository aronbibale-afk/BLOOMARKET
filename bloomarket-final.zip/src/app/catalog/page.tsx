"use client";

import { useMemo, useState } from "react";
import { useSearchParams } from "next/navigation";
import { Suspense } from "react";
import { GAMES } from "@/lib/games";
import { PRODUCTS } from "@/lib/mock-data";
import { ProductCard } from "@/components/ProductCard";
import { SearchIcon } from "@/components/Icon";

const TYPES = ["Devise", "Objet", "Brainrot", "Compte", "Service"] as const;
const SORTS = [
  { value: "popularity", label: "Popularité" },
  { value: "price-asc", label: "Prix croissant" },
  { value: "price-desc", label: "Prix décroissant" },
  { value: "rating", label: "Mieux notés" },
] as const;

const PAGE_SIZE = 8;

function CatalogContent() {
  const sp = useSearchParams();
  const initialGame = sp.get("game") ?? "";
  const initialQ = sp.get("q") ?? "";

  const [q, setQ] = useState(initialQ);
  const [game, setGame] = useState<string>(initialGame);
  const [types, setTypes] = useState<string[]>([]);
  const [maxPrice, setMaxPrice] = useState<number>(150);
  const [seller, setSeller] = useState<string>("");
  const [sort, setSort] = useState<string>("popularity");
  const [page, setPage] = useState(1);

  const sellers = useMemo(() => {
    const map = new Map<string, string>();
    PRODUCTS.forEach((p) => map.set(p.seller.id, p.seller.name));
    return Array.from(map.entries());
  }, []);

  const filtered = useMemo(() => {
    let list = [...PRODUCTS];
    if (q.trim()) {
      const needle = q.toLowerCase();
      list = list.filter(
        (p) =>
          p.title.toLowerCase().includes(needle) ||
          p.description.toLowerCase().includes(needle) ||
          p.seller.name.toLowerCase().includes(needle) ||
          p.tags.some((t) => t.includes(needle))
      );
    }
    if (game) list = list.filter((p) => p.gameSlug === game);
    if (types.length) list = list.filter((p) => types.includes(p.type));
    list = list.filter((p) => p.price <= maxPrice);
    if (seller) list = list.filter((p) => p.seller.id === seller);

    switch (sort) {
      case "price-asc":
        list.sort((a, b) => a.price - b.price);
        break;
      case "price-desc":
        list.sort((a, b) => b.price - a.price);
        break;
      case "rating":
        list.sort((a, b) => b.rating - a.rating);
        break;
      default:
        list.sort((a, b) => b.popularity - a.popularity);
    }
    return list;
  }, [q, game, types, maxPrice, seller, sort]);

  const totalPages = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE));
  const safePage = Math.min(page, totalPages);
  const pageItems = filtered.slice((safePage - 1) * PAGE_SIZE, safePage * PAGE_SIZE);

  function toggleType(t: string) {
    setPage(1);
    setTypes((prev) => (prev.includes(t) ? prev.filter((x) => x !== t) : [...prev, t]));
  }

  function reset() {
    setQ("");
    setGame("");
    setTypes([]);
    setMaxPrice(150);
    setSeller("");
    setSort("popularity");
    setPage(1);
  }

  // Suggestions (top 5 par title match)
  const suggestions = useMemo(() => {
    if (!q.trim()) return [];
    const needle = q.toLowerCase();
    return PRODUCTS.filter((p) => p.title.toLowerCase().includes(needle)).slice(0, 5);
  }, [q]);

  const [showSuggest, setShowSuggest] = useState(false);

  return (
    <div className="bg-mesh">
      <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6">
        <div className="mb-8">
          <h1 className="text-3xl font-bold tracking-tight sm:text-4xl">Catalogue</h1>
          <p className="mt-2 text-sm text-slate-400">{filtered.length} produits disponibles · Livraison rapide & sécurisée</p>
        </div>

        {/* Search bar */}
        <div className="relative mb-6">
          <div className="flex items-center gap-2 rounded-xl border border-white/10 bg-white/5 p-1.5 backdrop-blur">
            <SearchIcon className="ml-3 text-slate-400" size={18} />
            <input
              value={q}
              onChange={(e) => { setQ(e.target.value); setPage(1); setShowSuggest(true); }}
              onFocus={() => setShowSuggest(true)}
              onBlur={() => setTimeout(() => setShowSuggest(false), 150)}
              placeholder="Rechercher un produit, vendeur, tag…"
              className="flex-1 bg-transparent px-2 py-2.5 text-sm placeholder:text-slate-500 focus:outline-none"
            />
            <select
              value={sort}
              onChange={(e) => setSort(e.target.value)}
              className="rounded-lg bg-white/5 border border-white/10 px-3 py-2 text-sm focus:outline-none"
            >
              {SORTS.map((s) => <option key={s.value} value={s.value} className="bg-[#0d0d14]">{s.label}</option>)}
            </select>
          </div>
          {showSuggest && suggestions.length > 0 && (
            <div className="absolute left-0 right-0 top-full z-10 mt-2 glass rounded-xl p-2 shadow-2xl">
              {suggestions.map((s) => (
                <button
                  key={s.id}
                  onClick={() => { setQ(s.title); setShowSuggest(false); }}
                  className="flex w-full items-center gap-3 rounded-lg px-3 py-2 text-left text-sm hover:bg-white/5"
                >
                  <span className="text-xl">{s.emoji}</span>
                  <div className="flex-1">
                    <div className="font-medium">{s.title}</div>
                    <div className="text-xs text-slate-400">{s.seller.name} · {s.price.toFixed(2)}€</div>
                  </div>
                </button>
              ))}
            </div>
          )}
        </div>

        <div className="grid gap-6 lg:grid-cols-[260px_1fr]">
          {/* Filters */}
          <aside className="card p-5 h-fit lg:sticky lg:top-20">
            <div className="mb-5 flex items-center justify-between">
              <h3 className="text-sm font-semibold">Filtres</h3>
              <button onClick={reset} className="text-xs text-violet-400 hover:underline">Réinitialiser</button>
            </div>

            <div className="mb-5">
              <label className="mb-2 block text-xs font-semibold uppercase text-slate-400">Jeu</label>
              <select value={game} onChange={(e) => { setGame(e.target.value); setPage(1); }} className="w-full rounded-lg border border-white/10 bg-white/5 px-3 py-2 text-sm">
                <option value="" className="bg-[#0d0d14]">Tous les jeux</option>
                {GAMES.map((g) => <option key={g.slug} value={g.slug} className="bg-[#0d0d14]">{g.emoji} {g.name}</option>)}
              </select>
            </div>

            <div className="mb-5">
              <label className="mb-2 block text-xs font-semibold uppercase text-slate-400">Type</label>
              <div className="space-y-1.5">
                {TYPES.map((t) => (
                  <label key={t} className="flex cursor-pointer items-center gap-2 rounded-lg px-2 py-1.5 text-sm hover:bg-white/5">
                    <input type="checkbox" checked={types.includes(t)} onChange={() => toggleType(t)} className="accent-violet-500" />
                    {t}
                  </label>
                ))}
              </div>
            </div>

            <div className="mb-5">
              <label className="mb-2 block text-xs font-semibold uppercase text-slate-400">Prix max: <span className="text-white">{maxPrice}€</span></label>
              <input type="range" min={1} max={150} value={maxPrice} onChange={(e) => { setMaxPrice(Number(e.target.value)); setPage(1); }} className="w-full accent-violet-500" />
            </div>

            <div>
              <label className="mb-2 block text-xs font-semibold uppercase text-slate-400">Vendeur</label>
              <select value={seller} onChange={(e) => { setSeller(e.target.value); setPage(1); }} className="w-full rounded-lg border border-white/10 bg-white/5 px-3 py-2 text-sm">
                <option value="" className="bg-[#0d0d14]">Tous</option>
                {sellers.map(([id, name]) => <option key={id} value={id} className="bg-[#0d0d14]">{name}</option>)}
              </select>
            </div>
          </aside>

          {/* Results */}
          <div>
            {pageItems.length === 0 ? (
              <div className="card p-10 text-center">
                <div className="text-4xl mb-3">🔍</div>
                <h3 className="font-semibold">Aucun produit trouvé</h3>
                <p className="text-sm text-slate-400 mt-1">Essayez de modifier vos filtres.</p>
              </div>
            ) : (
              <>
                <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 xl:grid-cols-3">
                  {pageItems.map((p) => <ProductCard key={p.id} product={p} />)}
                </div>
                {totalPages > 1 && (
                  <div className="mt-10 flex items-center justify-center gap-2">
                    <button disabled={safePage === 1} onClick={() => setPage((p) => Math.max(1, p - 1))} className="btn-ghost rounded-lg px-3 py-2 text-sm disabled:opacity-40">Précédent</button>
                    {Array.from({ length: totalPages }).map((_, i) => {
                      const n = i + 1;
                      return (
                        <button key={n} onClick={() => setPage(n)} className={`h-9 w-9 rounded-lg text-sm ${n === safePage ? "btn-primary" : "btn-ghost"}`}>{n}</button>
                      );
                    })}
                    <button disabled={safePage === totalPages} onClick={() => setPage((p) => Math.min(totalPages, p + 1))} className="btn-ghost rounded-lg px-3 py-2 text-sm disabled:opacity-40">Suivant</button>
                  </div>
                )}
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

export default function CatalogPage() {
  return (
    <Suspense fallback={<div className="mx-auto max-w-7xl px-4 py-20 text-center text-slate-400">Chargement…</div>}>
      <CatalogContent />
    </Suspense>
  );
}
