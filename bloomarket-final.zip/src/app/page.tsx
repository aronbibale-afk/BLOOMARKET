import Link from "next/link";
import { GAMES } from "@/lib/games";
import { getPopularProducts, PRODUCTS } from "@/lib/mock-data";
import { ProductCard } from "@/components/ProductCard";

const STATS = [
  { value: "18 400+", label: "commandes cette semaine" },
  { value: "4.97", label: "note moyenne vendeurs" },
  { value: "< 8 min", label: "délai de livraison moyen" },
  { value: "100%", label: "remboursé si problème" },
];

const LIVE_SALES = [
  { user: "Axel_R.", item: "Dragon Fruit (Perm)", price: "89.99€", game: "🍎" },
  { user: "Mia_K.", item: "Tung Tung Sahur", price: "12.99€", game: "🧠" },
  { user: "LouD.", item: "Huge Hacked Cat", price: "79.99€", game: "🐾" },
  { user: "Sam_G.", item: "10M Beli", price: "5.49€", game: "🍎" },
  { user: "Jade_F.", item: "500K Sheckles", price: "6.99€", game: "🌱" },
  { user: "Hugo_T.", item: "Chroma Lightbringer", price: "59.99€", game: "🔪" },
];

export default function HomePage() {
  const popular = getPopularProducts(8);
  const onSale = PRODUCTS.filter((p) => p.oldPrice).slice(0, 4);

  return (
    <div>
      {/* ── Hero ── */}
      <section className="hero-bg relative overflow-hidden">
        <div className="absolute inset-0 grid-lines" />

        <div className="relative mx-auto max-w-7xl px-4 sm:px-6 py-16 lg:py-24">
          <div className="grid lg:grid-cols-[1fr_380px] gap-12 items-center">
            {/* Left — asymmetric hero text */}
            <div>
              <div className="inline-flex items-center gap-2 mb-6 rounded-full border border-[#1C2433] bg-[#0D1117] px-4 py-1.5">
                <span className="live-dot" />
                <span className="text-[12px] font-medium text-[#6B7A90]">18 400 commandes traitées cette semaine</span>
              </div>

              <h1 className="font-display font-800 text-[52px] sm:text-[64px] lg:text-[76px] leading-[0.95] tracking-tight text-white mb-6">
                La marketplace<br />
                <span className="gradient-text">Roblox</span><br />
                la plus rapide.
              </h1>

              <p className="text-[16px] text-[#6B7A90] leading-relaxed max-w-lg mb-8">
                Items, devises, Brainrots, comptes et services. Livraison garantie en moins de 10 minutes. Vendeurs vérifiés, paiement sécurisé.
              </p>

              <div className="flex flex-wrap items-center gap-3 mb-10">
                <Link href="/catalog" className="btn-mint rounded-xl px-7 py-3.5 text-[15px]">
                  Explorer le catalogue
                </Link>
                <Link href="/register" className="btn-ghost rounded-xl px-6 py-3.5 text-[15px]">
                  Vendre mes items →
                </Link>
              </div>

              {/* Trust badges */}
              <div className="flex flex-wrap items-center gap-5 text-[12px] text-[#6B7A90]">
                <span className="flex items-center gap-2">
                  <svg width="14" height="14" viewBox="0 0 14 14" fill="none" stroke="#3BF4A0" strokeWidth="1.5" strokeLinecap="round"><path d="M7 1l1.5 3 3.5.5-2.5 2.5.5 3.5L7 9l-3 1.5.5-3.5L2 4.5 5.5 4z"/></svg>
                  Vendeurs vérifiés
                </span>
                <span className="flex items-center gap-2">
                  <svg width="14" height="14" viewBox="0 0 14 14" fill="none" stroke="#3BF4A0" strokeWidth="1.5" strokeLinecap="round"><path d="M7 1v12M1 7h12"/><rect x="2" y="2" width="10" height="10" rx="2"/></svg>
                  Stripe · PayPal · Apple Pay
                </span>
                <span className="flex items-center gap-2">
                  <svg width="14" height="14" viewBox="0 0 14 14" fill="none" stroke="#3BF4A0" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"><path d="M2 7l3 3 7-7"/></svg>
                  Remboursement garanti
                </span>
              </div>
            </div>

            {/* Right — Live sales ticker */}
            <div className="hidden lg:block">
              <div className="glass rounded-2xl p-5 relative overflow-hidden">
                <div className="flex items-center justify-between mb-4">
                  <span className="font-display text-[13px] font-700 text-white uppercase tracking-widest">Ventes en direct</span>
                  <div className="flex items-center gap-1.5 text-[12px] text-[#3BF4A0]">
                    <span className="live-dot" />
                    <span>Live</span>
                  </div>
                </div>
                <div className="space-y-2.5">
                  {LIVE_SALES.map((sale, i) => (
                    <div
                      key={i}
                      className="flex items-center gap-3 rounded-xl bg-white/[0.03] border border-[#1C2433] px-3 py-2.5"
                      style={{ animationDelay: `${i * 0.5}s` }}
                    >
                      <span className="text-2xl flex-shrink-0">{sale.game}</span>
                      <div className="min-w-0 flex-1">
                        <div className="text-[13px] font-medium text-white truncate">{sale.item}</div>
                        <div className="text-[11px] text-[#6B7A90]">{sale.user}</div>
                      </div>
                      <div className="font-display font-700 text-[14px] text-[#3BF4A0] flex-shrink-0">{sale.price}</div>
                    </div>
                  ))}
                </div>
                <div className="absolute bottom-0 left-0 right-0 h-12 bg-gradient-to-t from-[#0D1117] to-transparent pointer-events-none rounded-b-2xl" />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ── Stats bar ── */}
      <div className="border-y border-[#1C2433] bg-[#0D1117]">
        <div className="mx-auto max-w-7xl px-4 sm:px-6">
          <div className="grid grid-cols-2 md:grid-cols-4 divide-x divide-[#1C2433]">
            {STATS.map((s) => (
              <div key={s.label} className="px-6 py-5 text-center">
                <div className="font-display font-800 text-[24px] text-white">{s.value}</div>
                <div className="text-[12px] text-[#6B7A90] mt-0.5">{s.label}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* ── Games ── */}
      <section className="mx-auto max-w-7xl px-4 sm:px-6 py-16">
        <div className="flex items-end justify-between mb-8">
          <div>
            <p className="section-label mb-2">Univers</p>
            <h2 className="font-display font-700 text-[28px] text-white">Choisir un jeu</h2>
          </div>
          <Link href="/catalog" className="text-[13px] text-[#6B7A90] hover:text-white transition-colors">
            Tout voir →
          </Link>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
          {GAMES.map((g) => (
            <Link
              key={g.slug}
              href={`/catalog?game=${g.slug}`}
              className="scan-card group p-4 text-center hover:border-transparent"
            >
              <div className={`mx-auto mb-3 h-14 w-14 rounded-2xl bg-gradient-to-br ${g.gradient} flex items-center justify-center text-3xl shadow-lg transition-transform duration-300 group-hover:scale-110`}>
                {g.emoji}
              </div>
              <div className="font-display font-600 text-[13px] text-white mb-1">{g.name}</div>
              <div className="text-[11px] text-[#6B7A90]">{g.players} joueurs</div>
            </Link>
          ))}
        </div>
      </section>

      {/* ── Popular products ── */}
      <section className="mx-auto max-w-7xl px-4 sm:px-6 pb-16">
        <div className="flex items-end justify-between mb-8">
          <div>
            <p className="section-label mb-2">Tendances</p>
            <h2 className="font-display font-700 text-[28px] text-white">Les plus populaires</h2>
          </div>
          <Link href="/catalog" className="text-[13px] text-[#6B7A90] hover:text-white transition-colors">
            Voir tout le catalogue →
          </Link>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {popular.map((p) => (
            <ProductCard key={p.id} product={p} />
          ))}
        </div>
      </section>

      {/* ── Promos ── */}
      {onSale.length > 0 && (
        <section className="bg-[#0D1117] border-y border-[#1C2433]">
          <div className="mx-auto max-w-7xl px-4 sm:px-6 py-16">
            <div className="flex items-end justify-between mb-8">
              <div>
                <p className="section-label mb-2" style={{ color: '#FF6B35' }}>Flash deals</p>
                <h2 className="font-display font-700 text-[28px] text-white">Promotions du moment</h2>
              </div>
              <Link href="/catalog?sort=sale" className="text-[13px] text-[#6B7A90] hover:text-white transition-colors">
                Toutes les promos →
              </Link>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              {onSale.map((p) => (
                <ProductCard key={p.id} product={p} />
              ))}
            </div>
          </div>
        </section>
      )}

      {/* ── CTA band ── */}
      <section className="mx-auto max-w-7xl px-4 sm:px-6 py-16">
        <div className="relative overflow-hidden rounded-2xl bg-[#0D1117] border border-[#1C2433] p-10 text-center">
          <div className="absolute inset-0 hero-bg opacity-50" />
          <div className="relative">
            <span className="badge-mint mb-4 inline-block">Pour les vendeurs</span>
            <h2 className="font-display font-800 text-[36px] sm:text-[48px] text-white mb-4">
              Tu vends des items Roblox ?<br />
              <span className="gradient-text">Rejoins Bloomarket.</span>
            </h2>
            <p className="text-[15px] text-[#6B7A90] max-w-lg mx-auto mb-8">
              Publie tes annonces gratuitement, encaisse via Stripe ou PayPal et profite d'un dashboard vendeur complet.
            </p>
            <div className="flex flex-wrap items-center justify-center gap-3">
              <Link href="/register" className="btn-mint rounded-xl px-8 py-3.5 text-[15px]">
                Créer mon compte vendeur
              </Link>
              <Link href="/dashboard/seller" className="btn-ghost rounded-xl px-6 py-3.5 text-[15px]">
                Voir le dashboard demo →
              </Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
