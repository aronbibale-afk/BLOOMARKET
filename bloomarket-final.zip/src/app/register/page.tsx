import Link from "next/link";
import { AuthShell, Field } from "@/components/AuthShell";

export default function RegisterPage() {
  return (
    <AuthShell
      title="Créer un compte"
      subtitle="Rejoignez 248k+ joueurs qui achètent et vendent en toute sécurité."
      bottom={<>Déjà inscrit ? <Link href="/login" className="text-violet-400 hover:underline">Se connecter</Link></>}
    >
      <form className="space-y-4">
        <div className="grid grid-cols-2 gap-3">
          <Field label="Prénom" placeholder="Lucas" name="firstName" />
          <Field label="Nom" placeholder="Martin" name="lastName" />
        </div>
        <Field label="Username Roblox" placeholder="MonPseudoRoblox" name="username" />
        <Field label="Email" type="email" placeholder="vous@exemple.com" name="email" />
        <Field label="Mot de passe" type="password" placeholder="Min. 8 caractères" name="password" hint="8 caractères minimum, dont 1 chiffre et 1 majuscule" />
        <label className="flex items-start gap-2 text-xs text-slate-400">
          <input type="checkbox" className="mt-0.5 accent-violet-500" />
          J&apos;accepte les <Link href="#" className="text-violet-400 hover:underline">CGU</Link> et la <Link href="#" className="text-violet-400 hover:underline">politique de confidentialité</Link>.
        </label>
        <button className="btn-primary w-full rounded-xl py-3 text-sm">Créer mon compte</button>

        <div className="my-4 flex items-center gap-3 text-xs text-slate-500">
          <div className="h-px flex-1 bg-white/10" /> OU <div className="h-px flex-1 bg-white/10" />
        </div>
        <div className="grid grid-cols-2 gap-3">
          <button className="btn-ghost rounded-xl py-2.5 text-sm">Google</button>
          <button className="btn-ghost rounded-xl py-2.5 text-sm">Discord</button>
        </div>
      </form>
    </AuthShell>
  );
}
