import Link from "next/link";
import { AuthShell, Field } from "@/components/AuthShell";

export default function ForgotPasswordPage() {
  return (
    <AuthShell
      title="Mot de passe oublié ?"
      subtitle="Entrez votre email, on vous envoie un lien de réinitialisation."
      bottom={<><Link href="/login" className="text-violet-400 hover:underline">← Retour à la connexion</Link></>}
    >
      <form className="space-y-4">
        <Field label="Email" type="email" placeholder="vous@exemple.com" name="email" />
        <button className="btn-primary w-full rounded-xl py-3 text-sm">Envoyer le lien</button>
      </form>
      <p className="mt-4 text-xs text-slate-500">Vous n&apos;avez pas reçu d&apos;email ? Vérifiez vos spams ou contactez le support.</p>
    </AuthShell>
  );
}
