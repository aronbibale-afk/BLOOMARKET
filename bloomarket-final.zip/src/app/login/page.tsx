import Link from "next/link";
import { AuthShell, Field } from "@/components/AuthShell";

export default function LoginPage() {
  return (
    <AuthShell
      title="Bon retour 👋"
      subtitle="Connectez-vous pour accéder à votre tableau de bord."
      bottom={<>Pas encore de compte ? <Link href="/register" className="text-violet-400 hover:underline">Inscription gratuite</Link></>}
    >
      <form className="space-y-4">
        <Field label="Email" type="email" placeholder="vous@exemple.com" name="email" />
        <Field label="Mot de passe" type="password" placeholder="••••••••" name="password" />
        <div className="flex items-center justify-between text-xs">
          <label className="flex items-center gap-2 text-slate-400">
            <input type="checkbox" className="accent-violet-500" /> Se souvenir de moi
          </label>
          <Link href="/forgot-password" className="text-violet-400 hover:underline">Mot de passe oublié ?</Link>
        </div>
        <button className="btn-primary w-full rounded-xl py-3 text-sm">Se connecter</button>

        <div className="my-4 flex items-center gap-3 text-xs text-slate-500">
          <div className="h-px flex-1 bg-white/10" /> OU <div className="h-px flex-1 bg-white/10" />
        </div>
        <div className="grid grid-cols-2 gap-3">
          <button className="btn-ghost rounded-xl py-2.5 text-sm">Google</button>
          <button className="btn-ghost rounded-xl py-2.5 text-sm">Discord</button>
        </div>
      </form>
    </AuthShell>
  );
}
