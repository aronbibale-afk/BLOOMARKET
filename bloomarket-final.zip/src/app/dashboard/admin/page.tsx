import { DashboardShell, StatCard } from "@/components/DashboardShell";
import { BarChart, LineChart } from "@/components/MiniChart";
import { MOCK_REVENUE_DATA } from "@/lib/mock-data";
import { CartIcon, ChartIcon, CheckIcon, DollarIcon, PackageIcon, ShieldIcon, TicketIcon, UsersIcon } from "@/components/Icon";

export default function AdminDashboard() {
  return (
    <DashboardShell section="admin" title="Administration" subtitle="Vue globale de la plateforme.">
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard label="Utilisateurs" value="248 412" sub="+1.2% / jour" icon={<UsersIcon size={18} />} />
        <StatCard label="Vendeurs actifs" value="3 248" sub="+82 / sem" icon={<ShieldIcon size={18} />} />
        <StatCard label="GMV (mois)" value="412 800€" sub="+18% vs M-1" icon={<DollarIcon size={18} />} />
        <StatCard label="Commission générée" value="20 640€" sub="5% GMV" icon={<ChartIcon size={18} />} />
      </div>

      <div className="mt-8 grid gap-6 lg:grid-cols-3">
        <div className="card p-6 lg:col-span-2">
          <h2 className="mb-4 text-lg font-semibold">Volume de transactions (6 mois)</h2>
          <LineChart data={MOCK_REVENUE_DATA.map((d) => ({ label: d.month, value: d.revenue * 80 }))} color="#7c5cff" />
        </div>
        <div className="card p-6">
          <h2 className="mb-4 text-lg font-semibold">Top jeux</h2>
          <BarChart data={[
            { label: "Blox", value: 412 },
            { label: "Brain", value: 380 },
            { label: "Pet", value: 290 },
            { label: "MM2", value: 180 },
            { label: "Garden", value: 120 },
          ]} color="#2dd4bf" />
        </div>
      </div>

      {/* Pending verifications */}
      <div className="mt-8 grid gap-6 lg:grid-cols-2">
        <div className="card p-6">
          <div className="mb-5 flex items-center justify-between">
            <h2 className="text-lg font-semibold">Vérifications vendeur en attente</h2>
            <span className="rounded-full bg-amber-500/15 px-2 py-0.5 text-xs text-amber-300">4 en attente</span>
          </div>
          <div className="space-y-3">
            {[
              { name: "GardenGod", date: "10 Mar 2026", docs: "CNI recto/verso" },
              { name: "MM2Newbie", date: "9 Mar 2026", docs: "Passeport" },
              { name: "BloxFruitsKing", date: "8 Mar 2026", docs: "CNI + IBAN" },
              { name: "BrainrotPro", date: "7 Mar 2026", docs: "CNI" },
            ].map((u) => (
              <div key={u.name} className="flex items-center gap-3 rounded-lg bg-white/5 p-3">
                <div className="flex h-9 w-9 items-center justify-center rounded-md bg-gradient-to-br from-violet-500 to-fuchsia-500 text-sm font-bold">
                  {u.name[0]}
                </div>
                <div className="flex-1">
                  <div className="font-medium text-sm">{u.name}</div>
                  <div className="text-xs text-slate-400">{u.docs} · soumis {u.date}</div>
                </div>
                <button className="rounded-md bg-emerald-500/20 px-2.5 py-1 text-xs text-emerald-300 hover:bg-emerald-500/30">Valider</button>
                <button className="rounded-md bg-rose-500/20 px-2.5 py-1 text-xs text-rose-300 hover:bg-rose-500/30">Refuser</button>
              </div>
            ))}
          </div>
        </div>

        <div className="card p-6">
          <div className="mb-5 flex items-center justify-between">
            <h2 className="text-lg font-semibold">Litiges en cours</h2>
            <span className="rounded-full bg-rose-500/15 px-2 py-0.5 text-xs text-rose-300">3 ouverts</span>
          </div>
          <div className="space-y-3">
            {[
              { id: "DSP-204", title: "Produit non livré", parties: "Emma L. vs GardenGod", date: "12 Mar" },
              { id: "DSP-203", title: "Pet manquant dans pack", parties: "Hugo R. vs BloxLegend", date: "11 Mar" },
              { id: "DSP-201", title: "Compte récupéré", parties: "Léa T. vs PixelKing", date: "9 Mar" },
            ].map((d) => (
              <div key={d.id} className="flex items-center gap-3 rounded-lg bg-white/5 p-3">
                <div className="flex h-9 w-9 items-center justify-center rounded-md bg-rose-500/15 text-rose-300">
                  <TicketIcon size={16} />
                </div>
                <div className="flex-1">
                  <div className="text-sm font-medium">{d.title}</div>
                  <div className="text-xs text-slate-400">{d.parties} · {d.date}</div>
                </div>
                <span className="font-mono text-xs text-slate-500">{d.id}</span>
                <button className="btn-ghost rounded-md px-2.5 py-1 text-xs">Médier</button>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Users */}
      <div className="mt-8 card p-6">
        <div className="mb-5 flex items-center justify-between">
          <h2 className="text-lg font-semibold">Utilisateurs récents</h2>
          <input placeholder="Rechercher un utilisateur…" className="rounded-lg bg-white/5 border border-white/10 px-3 py-1.5 text-sm w-64" />
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="text-left text-xs uppercase text-slate-500">
                <th className="pb-3">Utilisateur</th>
                <th className="pb-3">Email</th>
                <th className="pb-3">Type</th>
                <th className="pb-3">Inscription</th>
                <th className="pb-3 text-right">Statut</th>
                <th className="pb-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {[
                { name: "Lucas Martin", email: "lucas@email.com", type: "Acheteur", date: "12 Mar 2026", status: "Actif" },
                { name: "Emma Lopez", email: "emma@email.com", type: "Vendeur", date: "11 Mar 2026", status: "Vérifié" },
                { name: "Hugo Renaud", email: "hugo@email.com", type: "Affilié", date: "10 Mar 2026", status: "Actif" },
                { name: "Léa Tournier", email: "lea@email.com", type: "Acheteur", date: "9 Mar 2026", status: "Suspendu" },
              ].map((u) => (
                <tr key={u.email} className="hover:bg-white/5">
                  <td className="py-3 font-medium">{u.name}</td>
                  <td className="py-3 text-slate-400">{u.email}</td>
                  <td className="py-3"><span className="rounded-full bg-white/5 px-2 py-0.5 text-xs">{u.type}</span></td>
                  <td className="py-3 text-slate-400">{u.date}</td>
                  <td className="py-3 text-right">
                    <span className={`rounded-full px-2 py-0.5 text-xs ${
                      u.status === "Suspendu" ? "bg-rose-500/15 text-rose-300" :
                      u.status === "Vérifié" ? "bg-violet-500/15 text-violet-300" :
                      "bg-emerald-500/15 text-emerald-300"
                    }`}>
                      {u.status === "Vérifié" && <CheckIcon size={10} className="inline mr-0.5" />}
                      {u.status}
                    </span>
                  </td>
                  <td className="py-3 text-right">
                    <button className="text-xs text-violet-400 hover:underline">Voir</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Commissions */}
      <div className="mt-8 grid gap-4 sm:grid-cols-3">
        <div className="card p-5">
          <div className="text-xs text-slate-400 flex items-center gap-2"><CartIcon size={14} /> Commission marketplace</div>
          <div className="mt-2 text-2xl font-bold">5%</div>
          <div className="mt-1 text-xs text-slate-500">Sur chaque vente</div>
        </div>
        <div className="card p-5">
          <div className="text-xs text-slate-400 flex items-center gap-2"><PackageIcon size={14} /> Commission affiliés</div>
          <div className="mt-2 text-2xl font-bold">10%</div>
          <div className="mt-1 text-xs text-slate-500">Reversée aux créateurs</div>
        </div>
        <div className="card p-5">
          <div className="text-xs text-slate-400 flex items-center gap-2"><DollarIcon size={14} /> Total reversé (mois)</div>
          <div className="mt-2 text-2xl font-bold">18 942€</div>
          <div className="mt-1 text-xs text-emerald-400">+12% vs M-1</div>
        </div>
      </div>
    </DashboardShell>
  );
}
