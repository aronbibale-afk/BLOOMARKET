import { DashboardShell, StatCard } from "@/components/DashboardShell";
import { BarChart, LineChart } from "@/components/MiniChart";
import { MOCK_AFFILIATE_DATA } from "@/lib/mock-data";
import { ChartIcon, CheckIcon, DollarIcon, GiftIcon, UsersIcon } from "@/components/Icon";

export default function AffiliateDashboard() {
  const totalClicks = MOCK_AFFILIATE_DATA.reduce((a, b) => a + b.clicks, 0);
  const totalSales = MOCK_AFFILIATE_DATA.reduce((a, b) => a + b.sales, 0);
  const conversion = ((totalSales / totalClicks) * 100).toFixed(1);

  return (
    <DashboardShell section="affiliate" title="Programme d'affiliation" subtitle="Partagez votre code, gagnez 10% sur chaque vente.">
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard label="Clics (7j)" value={String(totalClicks)} sub="+24% vs s. dernière" icon={<UsersIcon size={18} />} />
        <StatCard label="Ventes (7j)" value={String(totalSales)} sub={`Taux: ${conversion}%`} icon={<GiftIcon size={18} />} />
        <StatCard label="Commissions (7j)" value="312€" sub="+58€" icon={<DollarIcon size={18} />} />
        <StatCard label="Total à vie" value="2 487€" icon={<ChartIcon size={18} />} />
      </div>

      {/* Promo code */}
      <div className="mt-8 card p-6 bg-gradient-to-br from-violet-600/20 via-fuchsia-500/10 to-transparent">
        <div className="grid gap-6 md:grid-cols-[1fr_auto] items-center">
          <div>
            <div className="text-xs uppercase text-violet-300">Votre code promo personnel</div>
            <div className="mt-2 flex items-center gap-3">
              <code className="rounded-lg border border-violet-500/30 bg-violet-500/10 px-4 py-2 text-2xl font-bold text-white">LUCAS10</code>
              <button className="btn-ghost rounded-lg px-3 py-2 text-xs">Copier</button>
            </div>
            <p className="mt-3 text-sm text-slate-400">Vos filleuls reçoivent <strong className="text-white">-10%</strong>, vous touchez <strong className="text-emerald-400">10% de commission</strong> sur chaque vente.</p>
          </div>
          <div className="rounded-xl bg-black/30 p-4">
            <div className="text-xs text-slate-400 mb-1">Lien de partage</div>
            <code className="block text-xs text-violet-300 break-all">bloomarket.com/?ref=LUCAS10</code>
            <div className="mt-3 flex gap-2">
              <button className="btn-ghost flex-1 rounded-md py-1.5 text-xs">Twitter</button>
              <button className="btn-ghost flex-1 rounded-md py-1.5 text-xs">Discord</button>
              <button className="btn-ghost flex-1 rounded-md py-1.5 text-xs">TikTok</button>
            </div>
          </div>
        </div>
      </div>

      <div className="mt-8 grid gap-6 lg:grid-cols-2">
        <div className="card p-6">
          <h2 className="mb-4 text-lg font-semibold">Clics par jour</h2>
          <LineChart data={MOCK_AFFILIATE_DATA.map((d) => ({ label: d.day, value: d.clicks }))} color="#a78bfa" />
        </div>
        <div className="card p-6">
          <h2 className="mb-4 text-lg font-semibold">Ventes par jour</h2>
          <BarChart data={MOCK_AFFILIATE_DATA.map((d) => ({ label: d.day, value: d.sales }))} color="#2dd4bf" />
        </div>
      </div>

      <div className="mt-8 card p-6">
        <h2 className="mb-5 text-lg font-semibold">Dernières commissions</h2>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="text-left text-xs uppercase text-slate-500">
                <th className="pb-3">Date</th>
                <th className="pb-3">Filleul</th>
                <th className="pb-3">Produit</th>
                <th className="pb-3 text-right">Montant vente</th>
                <th className="pb-3 text-right">Commission</th>
                <th className="pb-3 text-right">Statut</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {[
                { date: "12 Mar", buyer: "Emma L.", product: "Dragon Fruit", amount: 89.99, commission: 9.0, status: "Payée" },
                { date: "11 Mar", buyer: "Hugo R.", product: "100B Gems", amount: 9.99, commission: 1.0, status: "Payée" },
                { date: "10 Mar", buyer: "Léa T.", product: "Tung Tung Sahur", amount: 12.99, commission: 1.3, status: "En attente" },
                { date: "9 Mar", buyer: "Mathis P.", product: "Huge Hacked Cat", amount: 79.99, commission: 8.0, status: "Payée" },
              ].map((c, i) => (
                <tr key={i}>
                  <td className="py-2.5 text-slate-400">{c.date}</td>
                  <td className="py-2.5">{c.buyer}</td>
                  <td className="py-2.5">{c.product}</td>
                  <td className="py-2.5 text-right text-slate-400">{c.amount.toFixed(2)}€</td>
                  <td className="py-2.5 text-right font-semibold text-emerald-400">+{c.commission.toFixed(2)}€</td>
                  <td className="py-2.5 text-right text-xs">
                    <span className={`rounded-full px-2 py-0.5 ${c.status === "Payée" ? "bg-emerald-500/15 text-emerald-300" : "bg-amber-500/15 text-amber-300"}`}>
                      {c.status === "Payée" && <CheckIcon size={10} className="inline mr-0.5" />}
                      {c.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </DashboardShell>
  );
}
