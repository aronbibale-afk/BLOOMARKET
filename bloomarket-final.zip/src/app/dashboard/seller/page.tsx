import { DashboardShell, StatCard } from "@/components/DashboardShell";
import { LineChart, BarChart } from "@/components/MiniChart";
import { MOCK_REVENUE_DATA, MOCK_SELLER_SALES, PRODUCTS } from "@/lib/mock-data";
import { GAMES } from "@/lib/games";
import { ChartIcon, CheckIcon, DollarIcon, EditIcon, PackageIcon, PlusIcon, ShieldIcon, StarIcon, TrashIcon } from "@/components/Icon";

export default function SellerDashboard() {
  // Pretend 5 products belong to current seller
  const myProducts = PRODUCTS.slice(0, 5);

  return (
    <DashboardShell section="seller" title="Espace vendeur" subtitle="Gérez vos produits, suivez vos ventes, augmentez vos revenus.">
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard label="Revenus du mois" value="5 840€" sub="+42% vs M-1" icon={<DollarIcon size={18} />} />
        <StatCard label="Ventes" value="184" sub="+27 cette semaine" icon={<PackageIcon size={18} />} />
        <StatCard label="Note moyenne" value="4.9 ★" sub="312 avis" icon={<StarIcon size={18} />} />
        <StatCard label="Taux conversion" value="6.2%" sub="+0.8 pts" icon={<ChartIcon size={18} />} />
      </div>

      <div className="mt-8 grid gap-6 lg:grid-cols-3">
        <div className="card p-6 lg:col-span-2">
          <div className="mb-4 flex items-center justify-between">
            <h2 className="text-lg font-semibold">Revenus (6 derniers mois)</h2>
            <select className="rounded-lg bg-white/5 border border-white/10 px-3 py-1.5 text-xs">
              <option className="bg-[#0d0d14]">6 derniers mois</option>
              <option className="bg-[#0d0d14]">12 derniers mois</option>
            </select>
          </div>
          <LineChart data={MOCK_REVENUE_DATA.map((d) => ({ label: d.month, value: d.revenue }))} />
        </div>

        <div className="card p-6">
          <h2 className="mb-4 text-lg font-semibold">Vérification vendeur</h2>
          <div className="flex items-start gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-emerald-500/15 text-emerald-300"><ShieldIcon size={18} /></div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-semibold">Statut: Vérifié</span>
                <span className="inline-flex items-center gap-1 rounded-full bg-violet-500/15 px-2 py-0.5 text-[10px] text-violet-300"><CheckIcon size={10} /> Badge</span>
              </div>
              <p className="mt-1 text-xs text-slate-400">Carte d&apos;identité validée le 14/02/2026 par notre équipe.</p>
            </div>
          </div>
          <div className="mt-5 space-y-2 text-xs text-slate-400">
            <div className="flex items-center gap-2"><CheckIcon size={14} className="text-emerald-400" /> Email vérifié</div>
            <div className="flex items-center gap-2"><CheckIcon size={14} className="text-emerald-400" /> Téléphone vérifié</div>
            <div className="flex items-center gap-2"><CheckIcon size={14} className="text-emerald-400" /> Identité validée</div>
            <div className="flex items-center gap-2"><CheckIcon size={14} className="text-emerald-400" /> IBAN configuré</div>
          </div>
          <button className="btn-ghost mt-5 w-full rounded-lg py-2 text-xs">Mettre à jour mes infos</button>
        </div>
      </div>

      {/* Products */}
      <div className="mt-8 card p-6">
        <div className="mb-5 flex items-center justify-between">
          <h2 className="text-lg font-semibold">Mes produits</h2>
          <button className="btn-primary inline-flex items-center gap-2 rounded-lg px-3 py-2 text-sm">
            <PlusIcon size={16} /> Ajouter un produit
          </button>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="text-left text-xs uppercase text-slate-500">
                <th className="pb-3">Produit</th>
                <th className="pb-3">Jeu</th>
                <th className="pb-3">Stock</th>
                <th className="pb-3 text-right">Prix</th>
                <th className="pb-3 text-right">Ventes</th>
                <th className="pb-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {myProducts.map((p) => (
                <tr key={p.id} className="hover:bg-white/5">
                  <td className="py-3">
                    <div className="flex items-center gap-3">
                      <div className={`flex h-9 w-9 items-center justify-center rounded-md bg-gradient-to-br ${p.gradient}`}>{p.emoji}</div>
                      <div className="font-medium">{p.title}</div>
                    </div>
                  </td>
                  <td className="py-3 text-slate-400">{GAMES.find((g) => g.slug === p.gameSlug)?.name}</td>
                  <td className="py-3">{p.stock}</td>
                  <td className="py-3 text-right font-semibold">{p.price.toFixed(2)}€</td>
                  <td className="py-3 text-right text-slate-400">{p.reviewCount}</td>
                  <td className="py-3 text-right">
                    <div className="inline-flex gap-1">
                      <button className="rounded-md bg-white/5 p-2 hover:bg-white/10"><EditIcon size={14} /></button>
                      <button className="rounded-md bg-white/5 p-2 hover:bg-rose-500/20"><TrashIcon size={14} /></button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add product */}
      <div className="mt-8 card p-6">
        <h2 className="mb-5 text-lg font-semibold">Ajouter / Modifier un produit</h2>
        <div className="grid gap-4 md:grid-cols-2">
          <label className="block">
            <span className="mb-1.5 block text-xs font-semibold uppercase text-slate-400">Titre</span>
            <input className="w-full rounded-xl border border-white/10 bg-white/5 px-4 py-2.5 text-sm" placeholder="Ex: Dragon Fruit Permanent" />
          </label>
          <label className="block">
            <span className="mb-1.5 block text-xs font-semibold uppercase text-slate-400">Jeu</span>
            <select className="w-full rounded-xl border border-white/10 bg-white/5 px-4 py-2.5 text-sm">
              {GAMES.map((g) => <option key={g.slug} className="bg-[#0d0d14]">{g.name}</option>)}
            </select>
          </label>
          <label className="block">
            <span className="mb-1.5 block text-xs font-semibold uppercase text-slate-400">Type</span>
            <select className="w-full rounded-xl border border-white/10 bg-white/5 px-4 py-2.5 text-sm">
              {["Devise", "Objet", "Brainrot", "Compte", "Service"].map((t) => <option key={t} className="bg-[#0d0d14]">{t}</option>)}
            </select>
          </label>
          <label className="block">
            <span className="mb-1.5 block text-xs font-semibold uppercase text-slate-400">Prix (€)</span>
            <input type="number" step="0.01" className="w-full rounded-xl border border-white/10 bg-white/5 px-4 py-2.5 text-sm" placeholder="0.00" />
          </label>
          <label className="block md:col-span-2">
            <span className="mb-1.5 block text-xs font-semibold uppercase text-slate-400">Description</span>
            <textarea rows={4} className="w-full rounded-xl border border-white/10 bg-white/5 px-4 py-2.5 text-sm" placeholder="Décrivez votre produit…" />
          </label>
          <div className="md:col-span-2 flex justify-end gap-3">
            <button className="btn-ghost rounded-xl px-4 py-2.5 text-sm">Annuler</button>
            <button className="btn-primary rounded-xl px-4 py-2.5 text-sm">Publier</button>
          </div>
        </div>
      </div>

      {/* Sales */}
      <div className="mt-8 grid gap-6 lg:grid-cols-[1fr_400px]">
        <div className="card p-6">
          <h2 className="mb-5 text-lg font-semibold">Ventes récentes</h2>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="text-left text-xs uppercase text-slate-500">
                  <th className="pb-3">ID</th>
                  <th className="pb-3">Produit</th>
                  <th className="pb-3">Acheteur</th>
                  <th className="pb-3 text-right">Montant</th>
                  <th className="pb-3 text-right">Statut</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                {MOCK_SELLER_SALES.map((s) => (
                  <tr key={s.id}>
                    <td className="py-2.5 font-mono text-xs text-slate-400">{s.id}</td>
                    <td className="py-2.5">{s.product}</td>
                    <td className="py-2.5 text-slate-400">{s.buyer}</td>
                    <td className="py-2.5 text-right font-semibold">{s.amount.toFixed(2)}€</td>
                    <td className="py-2.5 text-right text-xs">
                      <span className={`rounded-full px-2 py-0.5 ${s.status === "Livrée" ? "bg-emerald-500/15 text-emerald-300" : "bg-amber-500/15 text-amber-300"}`}>{s.status}</span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
        <div className="card p-6">
          <h2 className="mb-4 text-lg font-semibold">Ventes par mois</h2>
          <BarChart data={MOCK_REVENUE_DATA.map((d) => ({ label: d.month, value: d.revenue }))} color="#a78bfa" />
        </div>
      </div>
    </DashboardShell>
  );
}
