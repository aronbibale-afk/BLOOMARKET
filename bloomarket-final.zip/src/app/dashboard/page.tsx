import Link from "next/link";
import { DashboardShell, StatCard } from "@/components/DashboardShell";
import { MOCK_ORDERS, getPopularProducts } from "@/lib/mock-data";
import { CartIcon, CheckIcon, HeartIcon, PackageIcon, StarIcon, TicketIcon } from "@/components/Icon";
import { ProductCard } from "@/components/ProductCard";

export default function UserDashboard() {
  const favorites = getPopularProducts(4);

  return (
    <DashboardShell section="user" title="Bienvenue, Lucas 👋" subtitle="Voici un aperçu de votre activité.">
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard label="Commandes" value="14" sub="+3 ce mois" icon={<PackageIcon size={18} />} />
        <StatCard label="Total dépensé" value="429€" sub="+89€ ce mois" icon={<CartIcon size={18} />} />
        <StatCard label="Favoris" value="8" icon={<HeartIcon size={18} />} />
        <StatCard label="Niveau membre" value="Gold" sub="VIP -10% bientôt" icon={<StarIcon size={18} />} />
      </div>

      {/* Profil */}
      <div className="mt-8 grid gap-6 lg:grid-cols-3">
        <div className="card p-6 lg:col-span-2">
          <h2 className="mb-5 text-lg font-semibold">Profil</h2>
          <div className="flex items-center gap-5">
            <div className="flex h-20 w-20 items-center justify-center rounded-2xl bg-gradient-to-br from-violet-500 to-fuchsia-500 text-4xl">
              🦊
            </div>
            <div>
              <div className="text-xl font-semibold">Lucas Martin</div>
              <div className="text-sm text-slate-400">@LucasOnRoblox · Membre depuis Jan. 2024</div>
              <div className="mt-1 inline-flex items-center gap-1 rounded-full bg-amber-500/15 px-2 py-0.5 text-xs text-amber-300">
                <StarIcon size={10} /> Statut Gold
              </div>
            </div>
          </div>
          <div className="mt-6 grid grid-cols-2 gap-3 text-sm">
            <div><div className="text-xs text-slate-400">Email</div><div>lucas.martin@email.com</div></div>
            <div><div className="text-xs text-slate-400">Username Roblox</div><div>LucasOnRoblox</div></div>
            <div><div className="text-xs text-slate-400">Pays</div><div>🇫🇷 France</div></div>
            <div><div className="text-xs text-slate-400">2FA</div><div className="text-emerald-400">Activé</div></div>
          </div>
        </div>

        <div className="card p-6">
          <h2 className="mb-3 text-lg font-semibold">Paramètres rapides</h2>
          <div className="space-y-2 text-sm">
            {["Email de notification", "Notifications push", "Newsletter", "Mode sombre"].map((p, i) => (
              <label key={p} className="flex items-center justify-between rounded-lg bg-white/5 px-3 py-2.5">
                {p}
                <input type="checkbox" defaultChecked={i !== 2} className="accent-violet-500" />
              </label>
            ))}
            <button className="btn-ghost mt-3 w-full rounded-lg py-2.5 text-sm">Changer mot de passe</button>
          </div>
        </div>
      </div>

      {/* Commandes */}
      <div className="mt-8 card p-6">
        <div className="mb-5 flex items-center justify-between">
          <h2 className="text-lg font-semibold">Historique des commandes</h2>
          <Link href="#" className="text-xs text-violet-400 hover:underline">Tout voir</Link>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="text-left text-xs uppercase text-slate-500">
                <th className="pb-3">Commande</th>
                <th className="pb-3">Produit</th>
                <th className="pb-3">Vendeur</th>
                <th className="pb-3">Date</th>
                <th className="pb-3 text-right">Montant</th>
                <th className="pb-3 text-right">Statut</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {MOCK_ORDERS.map((o) => (
                <tr key={o.id} className="hover:bg-white/5">
                  <td className="py-3 font-mono text-xs text-slate-400">{o.id}</td>
                  <td className="py-3">{o.product}</td>
                  <td className="py-3 text-slate-400">{o.seller}</td>
                  <td className="py-3 text-slate-400">{o.date}</td>
                  <td className="py-3 text-right font-semibold">{o.amount.toFixed(2)}€</td>
                  <td className="py-3 text-right">
                    <span className={`inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-xs ${
                      o.status === "Livrée" ? "bg-emerald-500/15 text-emerald-300" :
                      o.status === "En cours" ? "bg-amber-500/15 text-amber-300" :
                      "bg-rose-500/15 text-rose-300"
                    }`}>
                      {o.status === "Livrée" && <CheckIcon size={10} />}
                      {o.status === "Litige" && <TicketIcon size={10} />}
                      {o.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Favoris */}
      <div className="mt-8">
        <div className="mb-5 flex items-center justify-between">
          <h2 className="text-lg font-semibold">Mes favoris</h2>
          <Link href="/catalog" className="text-xs text-violet-400 hover:underline">Voir le catalogue</Link>
        </div>
        <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {favorites.map((p) => <ProductCard key={p.id} product={p} />)}
        </div>
      </div>
    </DashboardShell>
  );
}
