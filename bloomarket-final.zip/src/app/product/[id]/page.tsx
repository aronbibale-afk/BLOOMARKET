import Link from "next/link";
import { notFound } from "next/navigation";
import { getProductById, getSimilarProducts, REVIEWS } from "@/lib/mock-data";
import { getGameBySlug } from "@/lib/games";
import { ProductCard } from "@/components/ProductCard";
import { BoltIcon, CartIcon, CheckIcon, HeartIcon, ShieldIcon, StarIcon, TicketIcon } from "@/components/Icon";

export default async function ProductPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const product = getProductById(id);
  if (!product) return notFound();
  const game = getGameBySlug(product.gameSlug);
  const similar = getSimilarProducts(product, 4);
  const productReviews = REVIEWS.slice(0, 4);

  return (
    <div className="bg-mesh">
      <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6">
        {/* Breadcrumb */}
        <nav className="mb-6 flex items-center gap-2 text-xs text-slate-400">
          <Link href="/" className="hover:text-white">Accueil</Link>
          <span>/</span>
          <Link href="/catalog" className="hover:text-white">Catalogue</Link>
          {game && (
            <>
              <span>/</span>
              <Link href={`/catalog?game=${game.slug}`} className="hover:text-white">{game.name}</Link>
            </>
          )}
          <span>/</span>
          <span className="text-slate-300">{product.title}</span>
        </nav>

        <div className="grid gap-8 lg:grid-cols-[1.2fr_1fr]">
          {/* Images */}
          <div>
            <div className={`card relative aspect-[5/3] overflow-hidden bg-gradient-to-br ${product.gradient}`}>
              <div className="absolute inset-0 bg-grid opacity-30" />
              <div className="absolute inset-0 flex items-center justify-center text-[10rem] drop-shadow-2xl">{product.emoji}</div>
              {product.oldPrice && (
                <div className="absolute left-4 top-4 rounded-md bg-rose-500/90 px-3 py-1 text-sm font-semibold">
                  -{Math.round((1 - product.price / product.oldPrice) * 100)}% off
                </div>
              )}
            </div>
            <div className="mt-4 grid grid-cols-4 gap-3">
              {[product.emoji, "🎮", "⭐", "💎"].map((e, i) => (
                <div key={i} className={`card aspect-square flex items-center justify-center text-3xl bg-gradient-to-br ${product.gradient} opacity-90 hover:opacity-100`}>{e}</div>
              ))}
            </div>
          </div>

          {/* Info */}
          <div>
            {game && (
              <Link href={`/catalog?game=${game.slug}`} className="inline-flex items-center gap-1.5 rounded-full border border-white/10 bg-white/5 px-3 py-1 text-xs">
                {game.emoji} {game.name}
              </Link>
            )}
            <h1 className="mt-3 text-3xl font-bold tracking-tight sm:text-4xl">{product.title}</h1>

            <div className="mt-3 flex items-center gap-3 text-sm text-slate-400">
              <div className="flex items-center gap-1 text-amber-400">
                <StarIcon size={16} />
                <span className="font-semibold">{product.rating}</span>
              </div>
              <span>·</span>
              <span>{product.reviewCount} avis</span>
              <span>·</span>
              <span className="text-emerald-400">● En stock ({product.stock})</span>
            </div>

            <p className="mt-5 text-slate-300">{product.longDescription}</p>

            <div className="mt-6 flex flex-wrap gap-2">
              {product.tags.map((t) => (
                <span key={t} className="rounded-full border border-white/10 bg-white/5 px-3 py-1 text-xs text-slate-300">#{t}</span>
              ))}
            </div>

            <div className="mt-8 card p-6">
              <div className="flex items-end justify-between">
                <div>
                  {product.oldPrice && (
                    <div className="text-sm text-slate-500 line-through">{product.oldPrice.toFixed(2)}€</div>
                  )}
                  <div className="text-4xl font-bold text-white">{product.price.toFixed(2)}€</div>
                  <div className="mt-1 text-xs text-slate-400">TTC · Paiement Stripe sécurisé</div>
                </div>
                <div className="text-right text-xs text-slate-400">
                  <div className="flex items-center justify-end gap-1.5 text-emerald-400"><BoltIcon size={14} /> Livraison {product.delivery}</div>
                  <div className="mt-1 flex items-center justify-end gap-1.5"><ShieldIcon size={14} /> Achat protégé</div>
                </div>
              </div>

              <div className="mt-6 flex gap-3">
                <button className="btn-primary flex-1 rounded-xl px-4 py-3 text-sm flex items-center justify-center gap-2">
                  <CartIcon size={18} /> Acheter maintenant
                </button>
                <button className="btn-ghost rounded-xl px-4 py-3" aria-label="Ajouter aux favoris">
                  <HeartIcon size={18} />
                </button>
              </div>
            </div>

            {/* Seller */}
            <div className="mt-6 card p-5">
              <div className="text-xs font-semibold uppercase text-slate-400 mb-3">Vendeur</div>
              <div className="flex items-center gap-4">
                <div className="flex h-14 w-14 items-center justify-center rounded-xl bg-gradient-to-br from-violet-500/30 to-fuchsia-500/30 text-3xl">
                  {product.seller.avatar}
                </div>
                <div className="flex-1">
                  <div className="flex items-center gap-2">
                    <span className="font-semibold text-white">{product.seller.name}</span>
                    {product.seller.verified && (
                      <span className="inline-flex items-center gap-1 rounded-full bg-violet-500/15 px-2 py-0.5 text-[10px] font-semibold text-violet-300">
                        <CheckIcon size={10} /> Vérifié
                      </span>
                    )}
                  </div>
                  <div className="text-xs text-slate-400 mt-0.5">
                    ★ {product.seller.rating} · {product.seller.sales.toLocaleString("fr-FR")} ventes · Membre depuis {product.seller.memberSince}
                  </div>
                </div>
                <button className="btn-ghost rounded-lg px-3 py-2 text-xs">Voir profil</button>
              </div>
              <div className="mt-4 grid grid-cols-3 gap-3 text-center text-xs">
                <div className="rounded-lg bg-white/5 p-3"><div className="font-bold text-emerald-400">99%</div><div className="text-slate-400">Satisfaction</div></div>
                <div className="rounded-lg bg-white/5 p-3"><div className="font-bold text-violet-300">5 min</div><div className="text-slate-400">Réponse moy.</div></div>
                <div className="rounded-lg bg-white/5 p-3"><div className="font-bold text-amber-400">24/7</div><div className="text-slate-400">Disponible</div></div>
              </div>
            </div>
          </div>
        </div>

        {/* Reviews */}
        <section className="mt-16">
          <div className="mb-6 flex items-end justify-between">
            <h2 className="text-2xl font-bold">Avis vérifiés</h2>
            <Link href="#" className="text-sm text-slate-400 hover:text-white">Voir tous ({product.reviewCount}) →</Link>
          </div>
          <div className="grid gap-4 md:grid-cols-2">
            {productReviews.map((r) => (
              <div key={r.id} className="card p-5">
                <div className="mb-3 flex items-center gap-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded-full bg-white/5 text-xl">{r.avatar}</div>
                  <div>
                    <div className="font-medium">{r.user}</div>
                    <div className="text-xs text-slate-400">{r.date}</div>
                  </div>
                  <div className="ml-auto flex text-amber-400">
                    {Array.from({ length: r.rating }).map((_, i) => <StarIcon key={i} size={14} />)}
                  </div>
                </div>
                <p className="text-sm text-slate-300">&ldquo;{r.comment}&rdquo;</p>
              </div>
            ))}
          </div>
        </section>

        {/* Dispute */}
        <section className="mt-12 card p-6 flex flex-col sm:flex-row items-start sm:items-center gap-4">
          <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-rose-500/15 text-rose-300">
            <TicketIcon size={22} />
          </div>
          <div className="flex-1">
            <h3 className="font-semibold">Problème avec votre commande ?</h3>
            <p className="text-sm text-slate-400">Ouvrez un ticket de litige : un médiateur interviendra sous 24h.</p>
          </div>
          <Link href="/dashboard" className="btn-ghost rounded-xl px-4 py-2.5 text-sm">Ouvrir un ticket</Link>
        </section>

        {/* Similar */}
        {similar.length > 0 && (
          <section className="mt-16">
            <h2 className="mb-6 text-2xl font-bold">Produits similaires</h2>
            <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">
              {similar.map((p) => <ProductCard key={p.id} product={p} />)}
            </div>
          </section>
        )}
      </div>
    </div>
  );
}
